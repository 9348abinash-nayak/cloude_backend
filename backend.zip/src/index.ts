import express from "express";
import http from "http";
import { Server } from "socket.io";
import { db_connect } from "./config/db.ts";
import { initSocket } from "./socket/socket.ts";
import dotenv from 'dotenv'
import { roomRouter } from "./routes/room.routes.ts";
import cors from 'cors'
import { codeexecuteRouter } from "./routes/codeexcute.routes.ts";
dotenv.config()


const app = express();

app.use(cors({
  origin: "*",
  methods: ["GET", "POST"]
}));
app.use(express.json())

const server = http.createServer(app);
const FRONTEND_URL = "https://your-frontend.vercel.app";
const io = new Server(server, {
  cors: {
    origin: FRONTEND_URL,
    methods: ["GET", "POST"],
    credentials: true
  }
});


// DB connect
db_connect();


initSocket(io);

app.use("/room",roomRouter)
app.use("/code",codeexecuteRouter)

server.listen(process.env.PORT, () => {
  console.log(`Server running on ${process.env.PORT}`);
});